var express     = require("express"),
    bodyParser  = require("body-parser"),
    mongoose    = require("mongoose"),
    bCrypt      = require('bcrypt-nodejs'),
    User        = require("./models/user"),
    Goal        = require("./models/goal"), 
    Expenses    = require("./models/expense"),
    nodemailer  = require("nodemailer"),
    moment      = require("moment")
var app = express();

 
mongoose.connect("mongodb://localhost/fineance", {autoIndex: false});
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('public'));
app.set("view engine", "ejs");


//*****************APP DEVELOPMENT STARTS HERE********************

//GLOBAL CURRENT USERNAME (DO NOT REMOVE)
var currentUser;
var sum;

//ROUTES
app.get("/", function(req,res){    
    res.render("Fineance");
});

app.get("/homepage", function(req,res){
    
    res.render("homepage",{userVar: currentUser} ); 
    
});

app.get("/register", function(req,res){
    res.render("register");
});

app.get("/login", function(req,res){
    res.render("login");
});


app.get("/goals", function(req,res){
    
    Goal.find({myUsername: currentUser},function(err,result){
                if(err)
                {console.log("user data not found");}
                else{
                    goalsRes= result;
                    console.log(goalsRes);
                    res.render("goals", {userVar: currentUser, goalsRes: result});
                }
    });
});

app.get("/goals/delete/:del", function(req,res){
    var del = Number(req.params.del);
    
    Goal.find({myUsername: currentUser}, function(err,result){
        if(err){
            console.log("not found");
        }else{
            goalsRes = result;
            console.log(goalsRes);
            for(var i=0; i<goalsRes.length;i++){
                if(del==i){
                   var id = goalsRes[i]._id;
                    
                    Goal.findOneAndRemove({_id: id}, function(err, success){
                        if(err) console.log(err+ "Failed to delete");
                        else {
                            console.log("Success");
                            Goal.find({myUsername: currentUser},function(err,result){
                                if(err)
                                {console.log("user data not found");}
                                else{
                                    goalsRes= result;
                                    console.log(goalsRes);
                                    res.redirect("/goals");
                                }
                            });
                        }   
                    
                    });
                }
            }
        }
    });
});

app.get("/expenses", function(req,res){
    
    Expenses.find({myUsername: currentUser}, function(err,result){
       if(err) console.log(err);
        else{
            expRes = result;
            sum=0;
            for(var i=0; i<expRes.length;i++){
                sum+=Number(expRes[i].price);
            }
            console.log(expRes);
            res.render("expenses",{userVar: currentUser, expRes: result, sum: sum} );
        }
    });
    
});

app.get("/expenses/delete/:del", function(req,res){
    var del = Number(req.params.del);
    
    Expenses.find({myUsername: currentUser}, function(err,result){
        if(err){
            console.log("not found");
        }else{
            expRes = result;
            console.log(expRes);
            for(var i=0; i<expRes.length;i++){
                if(del==i){
                   var id = expRes[i]._id;
                    sum-=Number(expRes[i].price);
                    Expenses.findOneAndRemove({_id: id}, function(err, success){
                        if(err) console.log(err+ "Failed to delete");
                        else {
                            console.log("Success");
                            Expenses.find({myUsername: currentUser},function(err,result){
                                if(err)
                                {console.log("user data not found");}
                                else{
                                    expRes= result;
                                    console.log(expRes);
                                    res.redirect("/expenses");
                                }
                            });
                        }   
                    
                    });
                }
            }
        }
    });
});

app.get("/expenses/total", function(req,res){
    Expenses.find({myUsername: currentUser}, function(err,result){
       if(err) console.log(err);
        else{
            expRes = result;
            console.log(expRes);
            sum =0;
            
            for(var i = 0; i<expRes.length; i++){
                sum+=Number(expRes[i].price);
            }
            res.redirect("/expenses");
        }
    });
});

app.post("/expenses/edit/:edit", function(req,res){
    var edit = Number(req.params.edit);
    var myUsername = currentUser;
    var date = Date(req.body.date);
    var category = req.body.category;
    var price = Number(req.body.price);
    var init_price;
    Expenses.find({myUsername: currentUser}, function(err,result){
        if(err){
            console.log("not found");
        }else{
            expRes = result;
            
            for(var i=0; i<expRes.length;i++){
                if(edit==i){
                   var id = expRes[i]._id;
                    Expenses.findOne({_id:id},function(err,success){
                        if(err)console.log(err);
                        else{
                            Expenses.findOneAndUpdate({_id: id},{date: date, category: category, price: price},{sort:{_id: -1}, upsert: true}, function(err, success){
                            if(err) console.log(err+ "Failed to update");
                            else {
                                init_price=Number(success.price);


                                       sum-=init_price;
                                        console.log(price+"Price value");
                                       sum+=Number(req.body.price);

                                success.update({date: date, category: category, price: price});

                                console.log("Success");

                                Expenses.find({myUsername: currentUser},function(err,result){
                                    if(err)
                                    {console.log("user data not found");}
                                    else{
                                        expRes= result;
                                
                                        res.redirect("/expenses");
                                    }
                                });
                            }   
                        
                    });
                        }
                    });
                    
                }
            }
        }
    });
});

app.get("/monthly", function(req,res){
    
    
            
            var expRes;
            
            var shopSum;
            var entSum;
            var transSum;
            var foodSum;
            var grocSum;
            var saveSum;
            var maxSpend;
            
            Expenses.find({myUsername: currentUser}, function(err,result){
                if (err)console.log(err);
                else{
                    expRes = result;
            sum=0;
            for(var i=0; i<expRes.length;i++){
                sum+=Number(expRes[i].price);
                console.log("Sum in report: " + sum);
            }
                    
                    
                    grocSum=0;
                    
                     for(var i=0; i<expRes.length;i++){
                        if(expRes[i].category===("Groceries")){
                            console.log(expRes[i]);
                            grocSum+=expRes[i].price;
                            console.log("grocSum"+grocSum);
                        }
                     }
                    
                    shopSum=0;
                    
                     for(var i=0; i<expRes.length;i++){
                        if(expRes[i].category===("Shopping")){
                            console.log(expRes[i]);
                            shopSum+=expRes[i].price;
                            console.log("shopSum"+shopSum);
                        }
                     } 
                    
                    entSum=0;
                    
                     for(var i=0; i<expRes.length;i++){
                        if(expRes[i].category===("Entertainment")){
                            console.log(expRes[i]);
                            entSum+=expRes[i].price;
                            console.log("entSum"+entSum);
                        }
                     } 
                    
                    transSum=0;
                    
                     for(var i=0; i<expRes.length;i++){
                        if(expRes[i].category===("Transport")){
                            console.log(expRes[i]);
                            transSum+=expRes[i].price;
                            console.log("transSum"+transSum);
                        }
                     } 
                    
                    foodSum=0;
                    
                     for(var i=0; i<expRes.length;i++){
                        if(expRes[i].category===("Food")){
                            console.log(expRes[i]);
                            foodSum+=expRes[i].price;
                            console.log("foodSum"+foodSum);
                        }
                     } 
                    
                    
                Goal.find({myUsername: currentUser}, function(err,result2){
                    if(err) console.log(err);
                    else{
                        saveSum=0;
                        maxSpend=0;
                        for(var i= 0; i<result2.length; i++){
                            if(result2[i].goal===("Save"))
                                {
                                    saveSum+=Number(result2[i].magnitude);
                                }
                            if(result2[i].goal===("Maximum Expenses"))
                                {
                                    maxSpend+=Number(result2[i].magnitude);
                                }
                        }
                        console.log("saveSum: "+saveSum);
                        console.log("maxSpend: "+maxSpend);
                        
                        res.render("monthly",{userVar: currentUser, expRes: expRes, sum: sum,shopSum: shopSum,transSum: transSum, entSum: entSum,foodSum: foodSum, grocSum: grocSum,saveSum: saveSum, maxSpend: maxSpend} );
                    }
                });
            
                 
        
    
                }
            });
});


//END OF GET ROUTES

//REGISTER (POST DATA INTO DB)
app.post("/register", function(req,res){
       
    var myName = req.body.myName;
    var myEmail = req.body.myEmail;
    var myUsername = req.body.myUsername;
    var myPassword = req.body.myPassword;
    
    User.findOne({myUsername: myUsername}, function(err,user){
       
        if(err){
            console.log(err);
        }
        
        if(!user){
            var newUser = new User();
    
            newUser.myName = req.body.myName;
            newUser.myEmail = req.body.myEmail;
            newUser.myUsername = req.body.myUsername;
            newUser.myPassword = createHash(req.body.myPassword);
            
            User.create(newUser, function(err, newlyCreated){
                if(err){
                    console.log(err);
                    
                    return res.render('/register');
                } else           
                    res.redirect("/login");    
            }); 
        }
        
        else{
            console.log("A duplicate user already exists");
            
            return res.redirect("/register");
        }
    });
            
});

//LOGIN (RETRIEVE DATA FROM DB)
app.post("/login", function(req,res){
   
        var myUsername = req.body.myUsername;
        var myPassword = req.body.myPassword;
        
        User.findOne({myUsername: myUsername}, function(err,user){
           
            if(err){
                console.log(err);
            }
            
            if(!user){
                console.log("User not found!");
                
                return res.redirect("/login");
            }
            
            else{
                console.log(myPassword);
                console.log(user.myPassword);
                if(isValidPassword(myPassword,user.myPassword)){
                    currentUser = myUsername;
                return res.redirect("/homepage");
                }
                else console.log(err);
                
            }
        });
});

app.post("/goals", function(req,res){
    
    var myUsername = currentUser;
    var goal = req.body.goal;
    var magnitude = req.body.magnitude;
    var plan = req.body.plan;
    var priority = req.body.priority;
    var reason = req.body.reason;
    
    var newGoal = new Goal();
    
    
    newGoal.myUsername = currentUser;
    newGoal.goal = req.body.goal;
    newGoal.magnitude = req.body.magnitude;
    newGoal.plan = req.body.plan;
    newGoal.priority = req.body.priority;
    newGoal.reason = req.body.reason;
    
    Goal.create(newGoal, function(err, newlyCreated){
        if(err){
            console.log(err + "ERROR IDK WHAIIII ");
        }
        else{
            res.redirect("/goals");
            }
    });
});

app.post("/expenses", function(req,res){
   
    var myUsername = currentUser;
    var date = req.body.date;
    var category = req.body.category;
    var price = req.body.price;
    
    var newExpenses = new Expenses();
    
    newExpenses.myUsername = currentUser;
    newExpenses.date = req.body.date;
    newExpenses.category = req.body.category;
    newExpenses.price = req.body.price;
    sum+=Number(newExpenses.price);
    Expenses.create(newExpenses, function(err, newlyCreated){
       if(err)
           console.log(err);
        else{
            res.redirect("/expenses");
        }
    });
});


//LOGOUT
app.get("/logout", function(req, res){
    req.logout();
    res.redirect("/");
});


//EMAIL
app.post("/homepage", function(req,res){
    
    var custEmail;
    var myUsername = currentUser;
    User.findOne({myUsername: myUsername, custEmail: myEmail}, function(err, user){
        if(err){
                console.log(err);
            }
            
            if(!user){
                console.log("User not found!");
                
                return res.redirect("/homepage");
            }
            
            else{
                custEmail = myEmail;
                return res.redirect("/homepage");
            }
    });
    

    
    var transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'muhdfauzanfauzi@gmail.com',
        pass: 'mfmf2411997'
      }
    });

    var mailOptions = {
      from: 'muhdfauzanfauzi@gmail.com',
      to: custEmail,
      subject: 'Sending Email using Node.js',
      text: 'FineAnce sent you an email'
    };

    transporter.sendMail(mailOptions, function(error, info){
      if (error) {
        console.log(error);
      } else {
        console.log('Email sent: ' + info.response);
      }
    });

});



//Hash and Salt a Password in DB





var createHash = function(password){
 return bCrypt.hashSync(password, bCrypt.genSaltSync(10), null);
}

var isValidPassword = function(user, password){
        return bCrypt.compareSync(user,password);
    }

//Apply "*" route matcher 
app.get("*", function(req,res){
    res.send("Sorry, page not found.");
});

//Tell Express to listen for request (start server) on a particular port 
app.listen(3000, function(){ 
    console.log('Server has started!!!');
});

