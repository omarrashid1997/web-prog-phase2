var mongoose = require("mongoose");


var ExpensesSchema = new mongoose.Schema({
    myUsername  : {type: String, unique: true},
    date        : Date,
    category    : String,
    price       : Number
});

module.exports = mongoose.model("Expenses", ExpensesSchema);