var mongoose = require("mongoose");


var GoalsSchema = new mongoose.Schema({
    myUsername  : String,
    goal        : String,
    magnitude   : Number,
    plan        : Date,
    priority    : String,
    reason      : String
    
});

module.exports = mongoose.model("Goal", GoalsSchema);