var mongoose = require("mongoose");

var UserSchema = new mongoose.Schema({
    myName      : String, 
    myEmail     : String,
    myUsername  : {type: String, unique: true},
    myPassword  : String
    
    
});

module.exports = mongoose.model("User", UserSchema);


